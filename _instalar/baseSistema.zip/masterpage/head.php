<link href="/jquerycms/js/bootstrap/css/bootstrap.min.css" rel="stylesheet" media="screen">

<script type='text/javascript' src='/jquerycms/js/jquery-1.6.2.min.js'></script>
<script src="/jquerycms/js/bootstrap/js/bootstrap.min.js"></script>

<script src="/jquerycms/js/prettyPhoto/jquery.prettyPhoto.js"></script>
<link rel='stylesheet' href='/jquerycms/js/prettyPhoto/prettyPhoto.css' type='text/css' media='screen' charset='utf-8' />
<script type='text/javascript' src='/jquerycms/js/jquery.validate.min.js'></script>