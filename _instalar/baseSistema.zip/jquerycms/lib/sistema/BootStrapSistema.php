<?php

require_once dirname(__FILE__) . '/FncsSistema.php';
require_once dirname(__FILE__) . '/excessoes.php';
require_once dirname(__FILE__) . '/arquivos.php';
require_once dirname(__FILE__) . '/fend.php';
require_once dirname(__FILE__) . '/dataFuncoes.php';
require_once dirname(__FILE__) . '/internacionalizacao.php';
require_once dirname(__FILE__) . '/simple_cache_class.php';
require_once dirname(__FILE__) . '/simple_image.php';