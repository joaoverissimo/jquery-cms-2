<div class="footer">
    <div class="inner">
        &copy 2013 - Jquery Cms
    </div>
</div>