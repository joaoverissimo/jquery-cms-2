<link href="/jquerycms/js/bootstrap/css/bootstrap.min.css" rel="stylesheet" media="screen">
<link href="<?php echo $adm_folder; ?>/lib/css/<?php echo $adm_tema; ?>.css" rel="stylesheet" media="screen">
<link rel='stylesheet' href='/jquerycms/js/jquery-ui/css/ui-lightness/jquery-ui-1.8.19.custom.css' type='text/css' media='all' />

<script type='text/javascript' src='/jquerycms/js/jquery-1.6.2.min.js'></script>
<script src="/jquerycms/js/bootstrap/js/bootstrap.min.js"></script>
<script type='text/javascript' src='/jquerycms/js/jquery-ui/js/jquery-ui-1.8.19.custom.min.js'></script>
            
<script src="/jquerycms/js/jquery.quicksearch.js"></script>
<script src="/jquerycms/js/prettyPhoto/jquery.prettyPhoto.js"></script>
<link rel='stylesheet' href='/jquerycms/js/prettyPhoto/prettyPhoto.css' type='text/css' media='screen' charset='utf-8' />

<script type='text/javascript' src='<?php echo $adm_folder; ?>/lib/js/admin-scripts.js'></script>
