<?php
//REQUIRE e VALIDA PÁGINA
require_once '../../jquerycms/config.php';
require_once '../lib/admin.php';

$msg = "";
Fncs_ValidaQueryString("cod", "index.php");

//CONEXÃO E VALORES
$registro = new objJqueryadminuser($Conexao, true);
$registro->loadByCod($_GET["cod"]);
    
//POST
if (count($_POST) > 0) {
    $registro->setNome(issetpost('nome'));
    $registro->setMail(issetpost('mail'));
    $registro->setSenha(issetpost('senha'));
    $registro->setGrupo(issetpostInteger('grupo'));
    
    try {
        $exec = $registro->Save();

        if ($exec && $adm_tema != 'branco') {
            header("Location: index.php");
        } else {
            $msg = fEnd_MsgString("O registro foi salvo.$fEnd_closeTheIFrameImDone", 'success');
        }
    } catch (jquerycmsException $exc) {
        $msg = fEnd_MsgString("Ocorreram problemas ao inserir o registro.", 'error', $exc->getMessage());
    }
}

//FORM
$form = new autoform2();
$form->start("cadastro","","POST");
    
$form->text(__('jqueryadminuser.nome'), 'nome', $registro->getNome(), 1);
$form->text(__('jqueryadminuser.mail'), 'mail', $registro->getMail(), 1);
$form->text(__('jqueryadminuser.senha'), 'senha', $registro->getSenha(), 1);
$form->selectDb(__('jqueryadminuser.grupo'), 'grupo', $registro->getGrupo(), '', $Conexao, 'jqueryadmingrupo', 'cod', 'titulo');

    
$form->send_cancel("Salvar", $cancelLink);
$form->end();
?><!DOCTYPE HTML>
<html>
    <head>
        <title><?php echo __('table_jqueryadminuser');?> - Editar</title>

        <?php include '../lib/masterpage/head.php'; ?>
        <?php echo $form->getHead(); ?>
    </head>
    <body>        
        <?php include '../lib/masterpage/header.php'; ?>

        <div class="main">
            <div class="inner">
                <div class="page-header">
                    <h3><?php echo __('table_jqueryadminuser');?> <small>Editar</small></h3>
                </div>
                
                <?php echo $msg; ?>
                <?php echo $form->getForm(); ?>
            </div>
        </div>
        <?php include '../lib/masterpage/footer.php'; ?>
    </body>
</html>