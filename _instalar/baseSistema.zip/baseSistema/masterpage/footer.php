<footer id="footer">
    <hr>
    <p class="pull-right"><a href="#">Back to top</a> <br> <a href="/adm/">Admin</a></p>
    Criado com <a href='http://jquerycms.areadigitalbrasil.com.br/' target='_blank'>Jquery Cms</a><br>
    Theme Made by <a target="_blank" href="http://thomaspark.me">Thomas Park</a>. Contact him <a href="mailto:hello@thomaspark.me">hello@thomaspark.me</a>.<br>
    Code licensed under the <a target="_blank" href="http://www.apache.org/licenses/LICENSE-2.0">Apache License v2.0</a>.<br>
    Based on <a target="_blank" href="http://twitter.github.com/bootstrap/">Bootstrap</a>. Hosted on <a target="_blank" href="http://pages.github.com/">GitHub</a>. Icons from <a target="_blank" href="http://glyphicons.com/">Glyphicons</a>. Web fonts from <a target="_blank" href="http://www.google.com/webfonts">Google</a>.<p></p>
</footer>